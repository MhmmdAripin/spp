<!-- Sticky Footer -->
<div class="row">
    <div class="col-md-12">
        <div class="copyright">
        <span>Copyright © <?php echo SITE_NAME ." ". Date('Y') ?></span>
        </div>
    </div>
</div>